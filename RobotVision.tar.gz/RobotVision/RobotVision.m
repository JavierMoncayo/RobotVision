% 
% Default function of guide -> |Clear|
function varargout = RobotVision(varargin)
% ROBOTVISION MATLAB code for RobotVision.fig
%      ROBOTVISION, by itself, creates a new ROBOTVISION or raises the existing
%      singleton*.
%
%      H = ROBOTVISION returns the handle to a new ROBOTVISION or the handle to
%      the existing singleton*.
%
%      ROBOTVISION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ROBOTVISION.M with the given input arguments.
%
%      ROBOTVISION('Property','Value',...) creates a new ROBOTVISION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before RobotVision_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to RobotVision_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help RobotVision

% Last Modified by GUIDE v2.5 13-May-2014 16:21:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @RobotVision_OpeningFcn, ...
                   'gui_OutputFcn',  @RobotVision_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

%% Configure initial values of GUI (Defautl GUIDE function)
function RobotVision_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject; % Choose default command line output for RobotVision
guidata(hObject, handles);% Update handles structure
global url ChkArduino;% Initialice 'URL' and 'ChkArduino' as global variable
url = [];
ChkArduino = 0;
% Set default values and initialize buttons
% Load arrow image to plot into free movement buttons
I=imread('FBArrow.png');
for i=[2 1] % Handles of the pushbutton asociated to movements
    h = handles.(sprintf('pb%d', i));% 'sprintf' creates the strings 'pbi'
                                     % handles.(x) retrieves the field x 
                                     % from the handles structure
    set(h,'CData',I); %Set image al CData in each pushbutton.
    I=imrotate(I,180); %Rotate image for the next psuhbutton
end
I=imread('NWawwor.png');
for i=[3 6 5 4] % Handles of the pushbutton asociated to movements
    h = handles.(sprintf('pb%d', i));% 'sprintf' creates the strings 'pbi'
                                     % handles.(x) retrieves the field x 
                                     % from the handles structure
    set(h,'CData',I); %Set image al CData in each pushbutton.
    I=imrotate(I,90); %Rotate image for the next psuhbutton
end
clear I;
% Set axes1 as current axes and set initial position of |axes1|
axes(handles.axes1); %Set axes1 as current axes to display.
set(handles.axes1,'Position',[3.8,13,94.2,19.3]);
UpdateAxes(imread('TeamRobot.jpg'));
% Set edit text to see the current value of security distance
A=get(handles.slider4,'Value');
set(handles.text11,'String',num2str(A));
clear A;
% Clear selected default button of button panels
set(handles.uipanel3,'SelectedObject',[]);% Set none selected function main functionallity panel
set(handles.uipanel12,'SelectedObject',[]);% Set none selected function in free movement options.
% Set value of slider tolerance.
set(handles.slider5,'value',5);
set(handles.text13,'string',num2str(get(handles.slider5,'Value')));

%%
% --- Outputs from this function are returned to the command line.
function varargout = RobotVision_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

%% Generic control elemts.
%% 
% Connect button.
function pushbutton5_Callback(hObject, eventdata, handles)
% This buttons check if the IP is empty
global url
IP=get(handles.edit1,'String');% Get IP address
if isempty(IP)==1% Check if the IP string is empty
    red=[1 0 0];
    str='Not vali IP address';
    SetInfoPanel(handles.InfoText,red,str);% If is empty set info panel string
else
    url=strcat('http://',IP,':8080/shot.jpg'); %Concatenate horizontally 
                                               %string to make the complete 
                                               %URL.
    axes(handles.axes1); %Set axes1 as current axes to display.
end
%%
% Stop button
function pushbutton6_Callback(hObject, eventdata, handles)
% This button stop the function that is actually running.
if get(handles.radiobutton1,'Value') == 1 % Check if "Free movement' functions are available:
    set(handles.uipanel5,'Visible','Off'); % Set panel invisible
    set(handles.uipanel3,'SelectedObject',[]); % Clear selected object
    set(handles.uipanel12,'SelectedObject',[]); % Clear selected object
    UpdateAxes(imread('TeamRobot.jpg'));
    if isempty(get(handles.edit3,'string'))==0
        fclose(s1); % Close serial port.
        blue=[0 0 1];
        str='Serial port closed';
        SetInfoPanel(handles.InfoText,blue,str);
    end
end

if get(handles.radiobutton3,'Value') == 1 % Check if "FollowPerson" functions are available:
    set(handles.uipanel5,'Visible','Off'); % Set panel invisible
    set(handles.pushbutton20,'Value',0); % Set disable Preview option.
    set(handles.uipanel3,'SelectedObject',[]);% Set none selected function main functionallity panel
    set(handles.axes2,'Visible','Off'); % Set invisible axes 2.
    axes(handles.axes1); %Set axes1 as current axes to display.
    set(handles.axes1,'Position',[3.8,13,94.2,19.3]); % Set new position to axes1
    UpdateAxes(imread('TeamRobot.jpg')); % Set image "TeamRobot"
    if isempty(handles.edit3,'string')==0
        fclose(s1); % Close serial port.
        blue=[0 0 1];
        str='Serial port closed';
        SetInfoPanel(handles.InfoText,blue,str);
    end
    
end
%%
% This object is InfoText that is contain in 'InfoPanel'
function InfoText_Callback(hObject, eventdata, handles)
%% Generic paramenters
%%
% This edit text contain the IP address to use for read image.
function edit1_Callback(hObject, eventdata, handles)
global url 
IP=get(hObject,'String'); % Get IP address
if isempty(IP)==1 % Check if the IP string is empty
    red=[1 0 0]; % If is empty set info panel string
    str='|Not vali IP address|';
    SetInfoPanel(handles.InfoText,red,str);
else
    url=strcat('http://',IP,':8080/shot.jpg'); %Concatenate horizontally 
                                               %string to make the complete 
                                               %URL
    set(handles.uipanel12,'Visible','On');
end
%%
% This slider control the duration of each movement of the robot and 
% update static text string of slider value
function slider3_Callback(hObject, eventdata, handles)
A=get(handles.slider3,'Value');
str=strcat(num2str(A/10),'[s]');
set(handles.text6,'String',str);
clear A str;
%%
% This slider manage de security distance to follow the object
function slider4_Callback(hObject, eventdata, handles)
val=get(hObject,'Value'); % Set edit text to see the current value of security distance
set(handles.text11,'String',num2str(val));
clear val;
%%
% Arduino Check box. This check if user say that arduino is conected
function checkbox1_Callback(hObject, eventdata, handles)
global ChkArduino % ChkArduino control if Arduino board is conected to PC. 
                  % If is conected the instructions of each movement will 
                  % sent by COM port else the movements that the robot 
                  % have to do will be displayed in 'Info Panel'
ChkArduino=get(hObject,'Value');
if ChkArduino==1
    set(handles.uipanel13,'Visible','On');
else
    set(handles.uipanel13,'Visible','Off');
end



%% Functionality panels
%
% Main function panel
function uipanel3_SelectionChangeFcn(hObject, eventdata, handles)
global url
if isempty(url)==1 % Check if the IP address is a valid value.
   red=[1 0 0];
   str='Not valid IP address.';
   SetInfoPanel(handles.InfoText,red,str);
   set(handles.uipanel3,'SelectedObject',[]); % Clear selected option.
   clear red str
else
%% 
    switch get(eventdata.NewValue,'Tag') % Change 'Visible' property dependent 
                                         % what button is selected.
        case 'radiobutton1' % Free movement radiobutton
            set(handles.uipanel5,'Visible','on'); % Free movement options panel
            set(handles.uipanel6,'Visible','off'); % Wander panel options
            set(handles.uipanel9,'Visible','off'); % Follow person options panel
            set(handles.uipanel10,'Visible','off'); % Follow ball options panel
            set(handles.uipanel14,'Visible','off'); % Following distance panel
            set(handles.axes1,'Position',[3.8,13,94.2,19.3]); % Set new position Axes1
            set(handles.axes2,'Visible','Off');% Set 'Visible' Off Axes2
            set(handles.figure1,'CurrentAxes',handles.axes1);
        case 'radiobutton2' % Track line radiobutton
            set(handles.uipanel5,'Visible','off'); % Free movement options panel
            set(handles.uipanel6,'Visible','on'); % Wander panel options
            set(handles.uipanel9,'Visible','off'); % Follow person options panel
            set(handles.uipanel10,'Visible','off'); % Follow ball options panel
            set(handles.uipanel14,'Visible','on'); % Following distance panel
            set(handles.axes1,'Position',[3.8,13,94.2,19.3]); % Set new position Axes1
%            set(handles.axes1,'Position',[3.8,21.5,94.2,19.3]);% Set original position of axes1
            set(handles.axes2,'Visible','Off');% Set 'Visible' On axes2
            set(handles.figure1,'CurrentAxes',handles.axes1);
        case 'radiobutton3' % Free movement radiobutton
            set(handles.uipanel5,'Visible','off'); % Free movement options panel
            set(handles.uipanel6,'Visible','off'); % Wander panel options
            set(handles.uipanel9,'Visible','on'); % Follow person options panel
            set(handles.uipanel10,'Visible','off'); % Follow ball options panel
            set(handles.uipanel14,'Visible','on'); % Following distance panel
            set(handles.axes1,'Position',[3.8,21.5,94.2,19.3]);% Set original position of axes1
            set(handles.axes2,'Visible','On');% Set 'Visible' On axes2
            set(handles.figure1,'CurrentAxes',handles.axes1);
        case 'radiobutton4' % Free movement radiobutton
            set(handles.uipanel5,'Visible','off'); % Free movement options panel
            set(handles.uipanel6,'Visible','off'); % Wander panel options
            set(handles.uipanel9,'Visible','off'); % Follow person options panel
            set(handles.uipanel10,'Visible','on'); % Follow ball options panel
            set(handles.uipanel14,'Visible','on'); % Following distance panel
            set(handles.axes1,'Position',[3.8,21.5,94.2,19.3]);% Set original position of axes1
            set(handles.axes2,'Visible','On');% Set 'Visible' On axes2
            set(handles.figure1,'CurrentAxes',handles.axes1);
    end
end
%%
% Free movement panel
function uipanel12_SelectionChangeFcn(hObject, eventdata, handles)
% This panel contain the actions that user can do in free movement
% function.
% 1 -> View scene.
% 2 -> Detect and count people.
% 3 -> Detect and count faces.
%   In the two last options, the program will generate an historial of
%   detected people that could be see in "HistorialDetection" GUI
global url % For use URL as global variable
switch get(hObject,'Tag') % With this "Switch-Case" manage the 
                          % functionality in free movement mode and 
                          % identify active radiobutton by 'Tag'
    case 'radiobutton7' % View scene.
         while(get(handles.radiobutton7,'Value')==1) % Check if 'View Scene' 
                                                     % radiobutton value is 
                                                     %'true' and update axes
                                                     % with actual image from 
                                                     %IP camera.
            GetImage(url,1);% Use this function for see the current situation
         end
    case 'radiobutton8' %Detection and count people
        while(get(handles.radiobutton8,'Value')==1) % Check if 'Detect People' 
                                                     % radiobutton value is 
                                                     %'true' and update axes
                                                     % with actual image from 
                                                     %IP camera.
            Detect(url,'UpperBody');
        end
        
    case 'radiobutton9' %Detetion and count faces
         while(get(handles.radiobutton9,'Value')==1) % Check if 'Detect Faces' 
                                                     % radiobutton value is 
                                                     %'true' and update axes
                                                     % with actual image from 
                                                     %IP camera.
            Detect(url,[]);
        end
end


%% Movement buttons
%% Forward move buttons
function pb1_Callback(hObject, eventdata, handles)
% This buttons send a byte to move forward.
global ChkArduino s1;
if ChkArduino == 1
    data = MovementCode(1); % Get movement code from "MovementCode" function
    fwrite(s1,data,'uchar');
    clear data
end
SetInfoPanel(handles.InfoText,[0 1 0],'Moving forward');
%%
function pb3_Callback(hObject, eventdata, handles)
% Move right forward
global ChkArduino s1;
if ChkArduino == 1
    data = MovementCode(2); % Get movement code from "MovementCode" function
    fwrite(s1,data,'uchar');
    clear data
end
SetInfoPanel(handles.InfoText,[0 1 0],'Moving right forward');
%%
function pb6_Callback(hObject, eventdata, handles)
% Moving left forward
global ChkArduino s1;
if ChkArduino == 1
    data = MovementCode(3); % Get movement code from "MovementCode" function
    fwrite(s1,data,'uchar');
    clear data
end
SetInfoPanel(handles.InfoText,[0 1 0],'Moving left forward');
%% Back move buttons
function pb2_Callback(hObject, eventdata, handles)
% Moving back
global ChkArduino s1;
if ChkArduino == 1
    data = MovementCode(4); % Get movement code from "MovementCode" function
    fwrite(s1,data,'uchar');
    clear data
end
SetInfoPanel(handles.InfoText,[0 1 0],'Moving back');
%%
function pb4_Callback(hObject, eventdata, handles)
% Moving right back
global ChkArduino s1;
if ChkArduino == 1
    data = MovementCode(5); % Get movement code from "MovementCode" function
    fwrite(s1,data,'uchar');
    clear data
end
SetInfoPanel(handles.InfoText,[0 1 0],'Moving right back');
%%
function pb5_Callback(hObject, eventdata, handles)
% Move left back
global ChkArduino s1;
if ChkArduino == 1
    data = MovementCode(6); % Get movement code from "MovementCode" function
    fwrite(s1,data,'uchar');
    clear data
end
SetInfoPanel(handles.InfoText,[0 1 0],'Moving left back');
%%
% --- Executes on button press in pb7.
function pb7_Callback(hObject, eventdata, handles)
% hObject    handle to pb7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'),get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function InfoText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to InfoText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


function edit3_Callback(hObject, eventdata, handles)
global s1 % Set COM port 's1' as global variable.
COMNumber=get(hObject,'String'); % Get number of port COM.
COM=strcat('COM',COMNumber); % Create 'COMx' string.
s1 = serial(COM,'BaudRate', 9600);
fopen(s1); % Open serial port.

% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function uipanel12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


%%
% This button take images and try to detect people
function pushbutton16_Callback(hObject, eventdata, handles)

ReferenceDimension=[]; % bboxes = [x y width heigth];
while(isempty(ReferenceDimension==1))
    shotAx1 = GetImage(url,0); % Get image from IP camera and don't update axes.
    ReferenceDimension=DetectObject('UpperBody',shotAx1); % Try to detect people face in image;
end


% --- Executes on button press in pb8.
function pb8_Callback(hObject, eventdata, handles)
% hObject    handle to pb8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function slider4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

%% Other funtion

%% Generic functions
%%
% This function set string of Info Panel box.
function SetInfoPanel(handle,color,str)
% Input argument:
%   1 -> Object's handles.
%   2 -> Font Color.
%   3 -> String.
    set(handle,'ForegroundColor',color);
    set(handle,'String',str);
%%
% This function get an image from url.
function shot=GetImage(url,ChkUpdate)
% Input argument:
%   1 -> URL to load image.
%   2 -> ChkUpdate. 
%           This paramenter control if the image will be display
%              IF ChkUpdate == 1 -> Update current axes and return image
%              ELSE only return image.
% Output argument:
%   2 -> Image.
shot = imread(url);
if ChkUpdate == 1
    UpdateAxes(shot)
end
%%
% This function update current axes
function UpdateAxes(shot)
% Input argument:
%   1 -> Image to be displayed in the curret axes.
    fh = image(shot);
    set(fh,'CData',shot);
    drawnow;
    
%% Image processing funcitons
%%
% This function dectect objects using 'vision.CascadeObjectDetector'. 
function Detect(url,str)
shot = GetImage(url,0); % Get current image from IP camera and don't update axes now
bboxes = DetectObject(str,shot); % 'bboxes' contain the coordenates that go around the face
if isempty(bboxes)==0 % If no face has been detected
    if isempty(str)==1
        str='Face';
    end
    shot = insertObjectAnnotation(shot,'rectangle',bboxes,str);
end
UpdateAxes(shot);
%%
% This function detect objects in image usin
% 'vision.CascadeObjectDetector'. It use the 'Viola-Jones' algorithm.
function bbox=DetectObject(str,shot)
% Input argument:
%   1 -> str. Control what kind of object will try to detect
%   2 -> shot. Image to analize.
% Output argument:
%   1 -> bboxes. This is the coordenates of the rectangle that go around
%        the object that has been detected
if isempty(str)==1 % Check what kind of object have to detect. Default 'Faces'
    detector = vision.CascadeObjectDetector();
else % Else "str" object.
    detector = vision.CascadeObjectDetector(str); % Initialize ObjectDetector
end
bbox = step(detector,shot); % Apply the detector to the image.
                           % bbox contain [x y width height] coordenates of
                           % any detected object.

function [cent,area,imClean,rad]=reference(Im,thres,tolerance)
  % Calculate threshold
 %If we don�t have selected threshold, we have a function to calculate it
 if thres==0
        thres=graythresh(Im);       %This function computes a global threshold
 end
% RGB to BW
 imGray = rgb2gray(Im);        %We convert RGB image into GrayScale image
 imBinary = im2bw(imGray,thres); %Now convert from GrayScale to BW using calculated threshold or input threshold
 imBinary=imcomplement(imBinary);  %Complement image, black becomes white and white becomes black

 %% Removing Noise
se=strel('disk',2); %creates a flat disk-shaped structuring element with the specified radius,
imClean=imopen(imBinary,se); % performs morphological opening on the grayscale or binary image IM with the structuring element SE.
 %imClean=imclearborder(imClean,4); %Suppress light structures connected to image border.
 imClean=bwareaopen(imClean,1200); % removes from a binary image all connected components (objects) that have fewer than P pixels (radius of 20 pixels)
 %%  Find Circle
 polarity='bright'; %Ball is darker than background
[cent,rad]=findcircle(imClean,polarity);
area=rad.^2;
area=area*3.14159;
area=int16(area);        

%% FIND CIRCLE
%This function will find a circle in the image given, then it will
%calculate the circle's center within the image and the circle's radius
%
% PARAMETERS
%Input parameters: Image (already processed, BW format), polarity is a string ('Dark','Bright') to ease the imfindcircles function work 
%Output parameters: Cicle's center, Circle's radius

%%
function [center,radius]=findcircle(Im,polarity)
%Since we don�t know the ball's radius we'll scan for possible values of
%radius until we find it, starting by x value    
x=20;
[center,radius] = imfindcircles(Im,[x (x+20)],'ObjectPolarity',polarity);       %This function has as input parameters: image, radius range, and 'ObjectPolarity'('Dark','Bright') to indicate
                                                                                 %wether the ball is darker than background or brighter.
%This loop will be executed until a center, so radius, has been found
while ~size(center)
    %We treat to find circles using increases of 20 pixels, so the function
    %will work quickly
    x=x+20;
    [center,radius] = imfindcircles(Im,[x (x+20)],'ObjectPolarity',polarity);
    %Next loop is to return 0 for center and radius in case no circle has been found 
    if x>80
        center=0;
        radius=0;
        break;
    end
end
    if center>1 %We mark the circle found within the last figure in use
%      viscircles(center,radius,'edgecolor','b');
    end
%The values obtained will be rounded to units
center=int16(center); %We only need to know X position of the center:
radius=int16(radius);


%% Comunication function
%%
% This funciton return the code to send to arduino that depends the
% direction of movement.
function code=MovementCode(dir)
switch (dir)
    case 1 % Forward movement code
        code='f';
    case 2 % Rifght forward movement code
        code='r';
    case 3 % Left Forward movement code
        code='l';
    case 4 % Back movement code
        code='b';
    case 5 % Right back movement code
        code='d';
    case 6 % Lef back movement code
        code='i';
end     
%% Follow functions
%%
% This function check if the target move forward or back.
function ChkActualPosition(RefArea,ActArea,RefCenter,ActCenter,RefRad,ActRad,tolerance)
%   Input argument:
%       1 -> RefArea: Area of target in the moment that star tracking
%       2 -> ActArea: Last area of detectedd object.
%       3 -> RefCenter: Center of target in the moment that star tracking
%       4 -> ActCenter: Last area of detectedd object.
%       5 -> Tolerance:
%   Output argument:
%       1 -> Movement: Movement code corresponding to move forward or back.
%   Internal variables:
%       FB -> ForwardBack (FB). Boolean. If FB == 1 -> Go forward.
%       RL -> RightLeft (RL).
global ChkArduino s1;
if (abs(RefRad-ActRad)>tolerance)
if RefArea < ActArea % If area is minor:
    FB = 1;% Go back.
else                 % If area is larger:
    FB = 2; % Go forward
end
if RefCenter(1)-(80) > ActCenter(1)
    RL = 3; % Move left.
elseif RefCenter(1)+(80) < ActCenter(1);
    RL = 6; % Move right.
else 
    RL=0;   % No turn
end
Move = int16(FB+RL); % Concatenate result of comparation.
    switch (Move) % Check result and determinate movement to send.
        case 2
            Movement = MovementCode(1); % Move forward.
        case 5
            Movement = MovementCode(3); % Move left forward.
         case 8
             Movement = MovementCode(2); % Move right forward.
         case 1
              Movement = MovementCode(4); % Move back only.
        case 4
              Movement = MovementCode(6); % Move left back.
         case 7
           Movement = MovementCode(5); % Move right back.
    end
     
if ChkArduino == 1
    fwrite(s1,Movement,'uchar');
end
end
        
%% Follow people panel buttons
% This button start the detection and preview image
function pushbutton20_Callback(hObject, eventdata, handles)
global url; % Set URL as global variable for use it.
if(get(hObject,'Value')==1); % Check value of "CheckBox" for set enable "Start following" button
    set(handles.pushbutton16,'Enable','on'); % Set enable "Start following" button
    set(handles.axes1,'Position',[3.8,21.5,94.2,19.3]);% Set original position of axes1
    set(handles.axes2,'Visible','On');% Set 'Visible' On axes2
else
    set(handles.pushbutton16,'Enable','off'); % Set disable "Start following" button
    set(handles.uipanel5,'Visible','Off'); % Set panel invisible
    set(handles.pushbutton20,'Value',0); % Set disable Preview option.
    set(handles.axes2,'Visible','Off'); % Set invisible axes 2.
    axes(handles.axes1); %Set axes1 as current axes to display.
    set(handles.axes1,'Position',[3.8,13,94.2,19.3]); % Set new position to axes1
    UpdateAxes(imread('TeamRobot.jpg')); % Set image "TeamRobot"
end

while(get(hObject,'Value')==1) % Loop that provides functionality to this option.
    shotAx1 = GetImage(url,0); % Get image from IP camera and don't update axes.
    bboxes=DetectObject('UpperBody',shotAx1); % Try to detect people face in image;
    if isempty(bboxes)== 0 % If there are any object detected set annotation into image.
        shotAx1 = insertObjectAnnotation(shotAx1,...
                          'rectangle',bboxes,'Face'); % Set annotation in each frame.
    end
    set(handles.figure1, 'CurrentAxes', handles.axes1); % Set axes1 as current axes.
    UpdateAxes(shotAx1); % Update with the new image without any detected objec
end
clear shotAx1  bboxes; %Clear internal variables.


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% if isempty(get(handles.edit3,'string'))==0
%         fclose(s1); % Close serial port.
%         blue=[0 0 1];
%         str='Serial port closed';
%         SetInfoPanel(handles.InfoText,blue,str);
% end
delete(hObject);


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on button press in pushbutton21.
function pushbutton21_Callback(hObject, eventdata, handles)
global url;
thres=0;
tolerance = get(handles.slider5,'Value');
RefCenter=0;
while (RefCenter<10)
    shot = GetImage(url,0);
    set(handles.figure1, 'CurrentAxes', handles.axes1); % Set axes1 as current axes.
    UpdateAxes(shot);
    set(handles.figure1, 'CurrentAxes', handles.axes2); % Set axes1 as current axes.
    [RefCenter,RefArea,imClean,RefRad]=reference(shot,thres,tolerance);
    RefCenter=RefCenter(1);
    imshow(imClean);
end
while get(handles.radiobutton4,'Value')==1
   tolerance = get(handles.slider5,'Value');
   set(handles.figure1, 'CurrentAxes', handles.axes1); % Set axes1 as current axes.
   shot = GetImage(url,1);
   set(handles.figure1, 'CurrentAxes', handles.axes2); % Set axes1 as current axes.
   [ActCenter,ActArea,imClean,ActRad]=reference(shot,thres,tolerance);
    imshow(imClean);
    if(ActCenter>1)
    viscircles(ActCenter,ActRad,'edgecolor','b');
    end
    ActCenter=ActCenter(1);
%     ActCenter
%     ActArea
%     RefCenter;
%     RefArea;
    if ActCenter>10
        ChkActualPosition(RefArea,ActArea,RefCenter,ActCenter,RefRad,ActRad,tolerance);
    end
end

%% 
% Tolerance slider
% --- Executes on slider movement.
function slider5_Callback(hObject, eventdata, handles)
% Get tolerance value.
set(handles.text13,'string',num2str(get(handles.slider5,'Value')));


% --- Executes during object creation, after setting all properties.
function slider5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


%%
% Demo Button.
function pushbutton22_Callback(hObject, eventdata, handles)
global ChkArduino s1 url;
if ChkArduino == 1 % Check if arduino is conected to COMx
   
    set(handles.figure1,'CurrentAxes',handles.axes1);
    a=GetImage(url,1);
   data = MovementCode(4); % Get movement code from "MovementCode" function
   fwrite(s1,data,'uchar'); % Send movement code
   data = MovementCode(4); % Get movement code from "MovementCode" function
   fwrite(s1,data,'uchar'); % Send movement code
   a=GetImage(url,1);
    for i=0:1:4
    data = MovementCode(4); % Get movement code from "MovementCode" function
    fwrite(s1,data,'uchar'); % Send movement code
    a=GetImage(url,1);
    end
    data = MovementCode(1); % Get movement code from "MovementCode" function
   fwrite(s1,data,'uchar'); % Send movement code
   a=GetImage(url,1);
    clear a;
    data = MovementCode(1); % Get movement code from "MovementCode" function
   fwrite(s1,data,'uchar'); % Send movement code
   data = MovementCode(1); % Get movement code from "MovementCode" function
   fwrite(s1,data,'uchar'); % Send movement code
   for i=0:1:4
    data = MovementCode(3); % Get movement code from "MovementCode" function
    fwrite(s1,data,'uchar'); % Send movement code
    a=GetImage(url,1);
   end
    data = MovementCode(4); % Get movement code from "MovementCode" function
   fwrite(s1,data,'uchar'); % Send movement code
   a=GetImage(url,1);
   data = MovementCode(4); % Get movement code from "MovementCode" function
    clear a;
end


% --- Executes on button press in pushbutton23.
function pushbutton23_Callback(hObject, eventdata, handles)
global url;

%while get(handles.pushbutton23,'Value')==1
    set(handles.figure1, 'CurrentAxes', handles.axes1); % Set axes1 as current axes.
    shot = GetImage(url,0);
    %Ajuste umbral
    thres=graythresh(shot);
    %Blanco 1 Negro 0
    iGray=rgb2gray(shot);
    Ibw=im2bw(iGray,thres);
    %Morfolog�a
    %Filtro AreaOpening
    Ibwf=bwareaopen(Ibw,1000);
    %Eliminar bordes
    [B,L]=bwboundaries(Ibwf,'noholes');
    numRegions=max(L(:));
    %imshow(label2rgb(L));
    region=regionprops(L,'all');
    %Propiedades de la region: Excentricidad
    excent=[region.Eccentricity];
    lineas=find(excent>0.5);
    set(handles.figure1, 'CurrentAxes', handles.axes1); % Set axes1 as current axes.
    hold on;
    UpdateAxes(shot);
    for i=1:length(lineas)
        outline=B{lineas(i)};
        line(outline(:,2),outline(:,1),'Color','r','LineWidth',2);
    end
    pause(5);
    hold off;
%end
